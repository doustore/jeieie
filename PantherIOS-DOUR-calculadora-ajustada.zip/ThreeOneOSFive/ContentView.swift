import SwiftUI
import UIKit

struct ContentView: View {
    @State private var display = "0"
    @State private var storedValue: Double?
    @State private var pendingOperation: String?
    @State private var startsNewNumber = true
    @State private var history: [String] = []
    @State private var showHistory = false
    @State private var showKeyEntry = false
    @State private var showMainApp = false
    @State private var keyText = ""
    @State private var keyGateArmed = false

    private let orange = Color(red: 1.0, green: 0.59, blue: 0.0)
    private let darkKey = Color(red: 0.17, green: 0.17, blue: 0.18)
    private let lightKey = Color(red: 0.34, green: 0.34, blue: 0.35)

    private let rows: [[String]] = [
        ["⌫", "AC", "%", "÷"],
        ["7", "8", "9", "×"],
        ["4", "5", "6", "−"],
        ["1", "2", "3", "+"],
        ["+/−", "0", ".", "="]
    ]

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            calculator
        }
        .preferredColorScheme(.dark)
        .statusBarHidden(true)
        .sheet(isPresented: $showHistory) {
            historySheet
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .fullScreenCover(isPresented: $showKeyEntry) {
            DOURKeyEntryView(accessText: $keyText) {
                showKeyEntry = false
                showMainApp = true
            }
        }
        .fullScreenCover(isPresented: $showMainApp) {
            PatchProjectsView(ghostTheme: true)
        }
    }

    private var calculator: some View {
        GeometryReader { geo in
            let sideInset: CGFloat = 14
            let spacing: CGFloat = 10
            let widthBasedSize = (geo.size.width - sideInset * 2 - spacing * 3) / 4
            let heightBasedSize = (geo.size.height - 250 - spacing * 4) / 5
            let buttonSize = max(54, min(widthBasedSize, heightBasedSize))

            VStack(spacing: 0) {
                HStack {
                    Button { showHistory = true } label: {
                        Image(systemName: "clock.arrow.circlepath")
                            .font(.system(size: 27, weight: .medium))
                            .foregroundStyle(.white)
                            .frame(width: 72, height: 72)
                            .background(Color(red: 0.105, green: 0.105, blue: 0.11), in: Circle())
                            .overlay(Circle().stroke(Color.white.opacity(0.16), lineWidth: 1.2))
                    }
                    .accessibilityLabel("Historial")
                    Spacer()
                    Button { clearAll() } label: {
                        Image(systemName: "calculator")
                            .font(.system(size: 27, weight: .medium))
                            .foregroundStyle(.white)
                            .frame(width: 72, height: 72)
                            .background(Color(red: 0.105, green: 0.105, blue: 0.11), in: Circle())
                            .overlay(Circle().stroke(Color.white.opacity(0.16), lineWidth: 1.2))
                    }
                    .accessibilityLabel("Reiniciar calculadora")
                }
                .padding(.horizontal, 18)
                .padding(.top, 22)

                Spacer(minLength: 12)

                HStack {
                    Spacer()
                    Text(display)
                        .font(.system(size: min(geo.size.width * 0.18, 82), weight: .light, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.35)
                        .contentTransition(.numericText())
                        .padding(.horizontal, 26)
                }
                .frame(height: max(geo.size.height * 0.17, 120), alignment: .bottom)
                .padding(.bottom, 22)

                VStack(spacing: spacing) {
                    ForEach(Array(rows.enumerated()), id: \.offset) { _, row in
                        HStack(spacing: spacing) {
                            ForEach(row, id: \.self) { key in
                                Button { press(key) } label: {
                                    Text(key)
                                        .font(.system(size: key == "AC" ? buttonSize * 0.40 : buttonSize * 0.47,
                                                      weight: .regular, design: .rounded))
                                        .foregroundStyle(.white)
                                        .frame(width: buttonSize, height: buttonSize)
                                        .background(keyColor(key), in: Circle())
                                        .overlay(Circle().stroke(Color.white.opacity(0.10), lineWidth: 1.1))
                                        .contentShape(Circle())
                                }
                                .buttonStyle(.plain)
                                .accessibilityLabel(accessibilityName(key))
                            }
                        }
                    }
                }
                .padding(.horizontal, sideInset)
                .frame(maxWidth: .infinity)
                Spacer(minLength: 22)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black)
        }
        .ignoresSafeArea()
    }

    private var historySheet: some View {
        NavigationStack {
            List {
                if history.isEmpty {
                    Text("Todavía no hay operaciones")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(Array(history.enumerated()), id: \.offset) { _, item in
                        Text(item).font(.system(.body, design: .monospaced))
                    }
                }
            }
            .navigationTitle("Historial")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Borrar") { history.removeAll() }
                        .disabled(history.isEmpty)
                }
                ToolbarItem(placement: .topBarLeading) {
                    Button("Listo") { showHistory = false }
                }
            }
        }
        .preferredColorScheme(.dark)
    }

    private func keyColor(_ key: String) -> Color {
        if ["÷", "×", "−", "+", "="].contains(key) { return orange }
        if ["AC", "%", "⌫"].contains(key) { return lightKey }
        return darkKey
    }

    private func accessibilityName(_ key: String) -> String {
        switch key {
        case "⌫": return "Borrar último dígito"
        case "AC": return "Borrar todo"
        case "÷": return "Dividir"
        case "×": return "Multiplicar"
        case "−": return "Restar"
        case "+": return "Sumar"
        case "=": return "Igual"
        case "+/−": return "Cambiar signo"
        default: return key
        }
    }

    private func press(_ key: String) {
        if key == "AC" {
            // El acceso se activa al escribir cinco dígitos cualquiera,
            // borrarlos con AC y pulsar "=" después.
            if display.count == 5 && display.allSatisfy({ $0.isNumber }) {
                keyGateArmed = true
            }
            clearAll(keepGate: true)
            return
        }
        if key == "⌫" {
            if !startsNewNumber {
                display = String(display.dropLast())
                if display.isEmpty || display == "-" { display = "0"; startsNewNumber = true }
            }
            return
        }
        if key == "=" {
            if keyGateArmed {
                keyGateArmed = false
                keyText = ""
                showKeyEntry = true
            } else {
                calculate()
            }
            return
        }
        if ["+", "−", "×", "÷"].contains(key) {
            setOperation(key)
            return
        }
        if key == "%" {
            if let value = Double(display) { display = format(value / 100) }
            startsNewNumber = true
            return
        }
        if key == "+/−" {
            if let value = Double(display) { display = format(-value) }
            return
        }
        if key == "." {
            if startsNewNumber { display = "0."; startsNewNumber = false }
            else if !display.contains(".") { display += "." }
            return
        }
        if key.first?.isNumber == true {
            if startsNewNumber || display == "0" {
                display = key
                startsNewNumber = false
            } else if display.count < 12 {
                display += key
            }
        }
    }

    private func setOperation(_ operation: String) {
        guard let value = Double(display) else { return }
        if let pendingOperation, let storedValue {
            let result = apply(storedValue, value, pendingOperation)
            self.storedValue = result
            display = format(result)
        } else {
            storedValue = value
        }
        pendingOperation = operation
        startsNewNumber = true
    }

    private func calculate() {
        guard let operation = pendingOperation,
              let left = storedValue,
              let right = Double(display) else { return }
        let result = apply(left, right, operation)
        history.insert("\(format(left)) \(operation) \(format(right)) = \(format(result))", at: 0)
        display = format(result)
        storedValue = nil
        pendingOperation = nil
        startsNewNumber = true
    }

    private func apply(_ left: Double, _ right: Double, _ operation: String) -> Double {
        switch operation {
        case "+": return left + right
        case "−": return left - right
        case "×": return left * right
        case "÷": return right == 0 ? .nan : left / right
        default: return right
        }
    }

    private func format(_ value: Double) -> String {
        guard value.isFinite else { return "Error" }
        if value == 0 { return "0" }
        if abs(value) >= 1e12 || abs(value) < 1e-7 {
            return String(format: "%.6g", value)
        }
        let result = String(format: "%.8f", value)
        return result.replacingOccurrences(of: #"\.?0+$"#, with: "", options: .regularExpression)
    }

    private func clearAll(keepGate: Bool = false) {
        display = "0"
        storedValue = nil
        pendingOperation = nil
        startsNewNumber = true
        if !keepGate { keyGateArmed = false }
    }
}

private struct DOURKeyEntryView: View {
    @Binding var accessText: String
    let onContinue: () -> Void
    @FocusState private var fieldFocused: Bool

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 22) {
                Spacer()
                Text("DOUR")
                    .font(.system(size: 44, weight: .black, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(Color(red: 1.0, green: 0.59, blue: 0.0))
                Text("Ingrese su key")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(.white.opacity(0.75))
                TextField("Key", text: $accessText)
                    .focused($fieldFocused)
                    .font(.system(size: 18, weight: .semibold, design: .monospaced))
                    .foregroundStyle(.white)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(.horizontal, 20)
                    .frame(height: 60)
                    .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 16))
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.18), lineWidth: 1))
                Button(action: onContinue) {
                    Text("CONTINUAR")
                        .font(.system(size: 17, weight: .bold, design: .rounded))
                        .tracking(1.5)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 60)
                        .background(Color(red: 1.0, green: 0.59, blue: 0.0), in: RoundedRectangle(cornerRadius: 17))
                }
                .buttonStyle(.plain)
                Spacer()
            }
            .padding(.horizontal, 30)
            .frame(maxWidth: 500)
        }
        .preferredColorScheme(.dark)
    }
}
